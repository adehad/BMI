Please download the data from: https://imperiallondon-my.sharepoint.com/:f:/g/personal/afh115_ic_ac_uk/EjncNZk1edRGgOWR9QkAlxcBLIYEKSiwvaZdhQlDohX2sw?e=crdRQn 

Required files:
	featureExtractedData.mat
	yExtractedData.mat